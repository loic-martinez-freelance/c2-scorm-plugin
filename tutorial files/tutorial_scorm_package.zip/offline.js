﻿{
	"version": 1486049523,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"images/white_button-sheet0.png",
		"images/green_button-sheet0.png",
		"images/9patch.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png",
		"imsmanifest.xml"
	]
}